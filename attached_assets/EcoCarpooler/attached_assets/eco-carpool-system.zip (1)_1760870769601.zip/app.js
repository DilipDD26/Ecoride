// Application Data from JSON
const appData = {
  "routes": [
    {
      "id": 1,
      "from": "Connaught Place, Delhi",
      "to": "Cyber City, Gurgaon", 
      "distance": "28 km",
      "duration": "45 mins",
      "safetyScore": 85,
      "ecoImpact": "4.2 kg CO2 saved",
      "price": "₹180",
      "availableSeats": 3
    },
    {
      "id": 2,
      "from": "Karol Bagh, Delhi",
      "to": "Noida Sector 62",
      "distance": "35 km", 
      "duration": "55 mins",
      "safetyScore": 92,
      "ecoImpact": "5.1 kg CO2 saved",
      "price": "₹220",
      "availableSeats": 2
    },
    {
      "id": 3,
      "from": "Dwarka, Delhi",
      "to": "Aerocity",
      "distance": "15 km",
      "duration": "25 mins",
      "safetyScore": 78,
      "ecoImpact": "2.8 kg CO2 saved",
      "price": "₹120",
      "availableSeats": 1
    }
  ],
  "drivers": [
    {
      "id": 1,
      "name": "Rajesh Kumar",
      "rating": 4.8,
      "vehicle": "Honda City 2020",
      "rides": 247,
      "ecoContribution": "1.2 tons CO2 saved",
      "safetyBadge": "Gold",
      "phone": "+91-9876543210"
    },
    {
      "id": 2,
      "name": "Priya Singh",
      "rating": 4.9,
      "vehicle": "Toyota Innova 2021",
      "rides": 189,
      "ecoContribution": "980 kg CO2 saved",
      "safetyBadge": "Platinum",
      "phone": "+91-9876543211"
    },
    {
      "id": 3,
      "name": "Amit Sharma",
      "rating": 4.7,
      "vehicle": "Maruti Swift 2019",
      "rides": 156,
      "ecoContribution": "750 kg CO2 saved", 
      "safetyBadge": "Silver",
      "phone": "+91-9876543212"
    }
  ],
  "systemStats": {
    "totalUsers": 45678,
    "activeDrivers": 12450,
    "ridesCompleted": 234567,
    "co2Saved": "234.5 tons",
    "safetyIncidents": 23,
    "luggageDelivered": 5679
  },
  "safetyFeatures": [
    "Real-time GPS tracking",
    "Emergency SOS button",
    "Driver background verification",
    "Route safety scoring",
    "24/7 support center",
    "Ride sharing with contacts"
  ],
  "ecoMetrics": {
    "avgCO2SavedPerRide": "3.8 kg",
    "monthlyReduction": "18.7 tons",
    "treesEquivalent": "847 trees planted",
    "fuelSaved": "23,450 liters"
  },
  "luggageServices": [
    {
      "id": 1,
      "type": "Small Package",
      "maxWeight": "5 kg",
      "price": "₹50",
      "deliveryTime": "Same day"
    },
    {
      "id": 2,
      "type": "Documents",
      "maxWeight": "1 kg", 
      "price": "₹30",
      "deliveryTime": "Express 2-4 hours"
    }
  ],
  "paymentMethods": [
    "Credit/Debit Card",
    "UPI",
    "Digital Wallet",
    "Net Banking",
    "Cash"
  ]
};

// Application State
let currentView = 'landing';
let currentUser = null;
let searchResults = [];

// Global variables for DOM elements
let navTabs, viewSections, loginBtn, signupBtn, loginModal, signupModal, ridesContainer;

// Initialize App
document.addEventListener('DOMContentLoaded', function() {
    console.log('Initializing EcoRide application...');
    
    // Cache DOM elements
    navTabs = document.querySelectorAll('.nav-tab');
    viewSections = document.querySelectorAll('.view-section');
    loginBtn = document.getElementById('loginBtn');
    signupBtn = document.getElementById('signupBtn');
    loginModal = document.getElementById('loginModal');
    signupModal = document.getElementById('signupModal');
    ridesContainer = document.getElementById('ridesContainer');
    
    initializeNavigation();
    initializeModals();
    initializeForms();
    initializeRoleCards();
    loadInitialData();
    setCurrentDate();
    
    // Initialize admin chart after a short delay to ensure DOM is ready
    setTimeout(initializeAdminChart, 100);
    
    console.log('EcoRide app initialized successfully!');
});

// Navigation System
function initializeNavigation() {
    console.log('Found nav tabs:', navTabs.length);
    
    navTabs.forEach((tab, index) => {
        // Remove any existing listeners
        const newTab = tab.cloneNode(true);
        tab.parentNode.replaceChild(newTab, tab);
        
        newTab.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const targetView = this.getAttribute('data-view');
            console.log('Tab clicked:', targetView);
            if (targetView) {
                switchView(targetView);
            }
        });
    });
    
    // Update navTabs reference after cloning
    navTabs = document.querySelectorAll('.nav-tab');
}

function switchView(view) {
    console.log('Switching view to:', view);
    
    // Update active tab
    navTabs.forEach(tab => {
        tab.classList.remove('active');
    });
    
    const activeTab = document.querySelector(`[data-view="${view}"]`);
    if (activeTab) {
        activeTab.classList.add('active');
        console.log('Set active tab for:', view);
    }
    
    // Show target view
    viewSections.forEach(section => {
        section.classList.remove('active');
        section.style.display = 'none';
    });
    
    const targetSection = document.getElementById(view);
    if (targetSection) {
        targetSection.classList.add('active');
        targetSection.style.display = 'block';
        console.log('Showing view:', view);
    } else {
        console.error('Target section not found:', view);
    }
    
    currentView = view;
    
    // Load view-specific data
    if (view === 'user') {
        setTimeout(() => {
            loadAvailableRides();
        }, 50);
    } else if (view === 'admin') {
        setTimeout(() => {
            updateAdminDashboard();
            initializeAdminChart();
        }, 50);
    }
}

// Modal Management
function initializeModals() {
    // Login Modal
    if (loginBtn) {
        loginBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showModal('loginModal');
        });
    }
    
    // Signup Modal  
    if (signupBtn) {
        signupBtn.addEventListener('click', function(e) {
            e.preventDefault();
            showModal('signupModal');
        });
    }
    
    // Close modal handlers
    document.querySelectorAll('.modal-close').forEach(closeBtn => {
        closeBtn.addEventListener('click', function(e) {
            e.preventDefault();
            const modal = e.target.closest('.modal');
            if (modal) {
                hideModal(modal.id);
            }
        });
    });
    
    // Close modal on backdrop click
    document.querySelectorAll('.modal').forEach(modal => {
        modal.addEventListener('click', function(e) {
            if (e.target === modal) {
                hideModal(modal.id);
            }
        });
    });
}

function showModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.remove('hidden');
        console.log('Showing modal:', modalId);
    }
}

function hideModal(modalId) {
    const modal = document.getElementById(modalId);
    if (modal) {
        modal.classList.add('hidden');
        console.log('Hiding modal:', modalId);
    }
}

// Form Handlers
function initializeForms() {
    // Login Form
    const loginForm = document.querySelector('.login-form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleLogin();
        });
    }
    
    // Signup Form
    const signupForm = document.querySelector('.signup-form');
    if (signupForm) {
        signupForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleSignup();
        });
    }
    
    // Ride Search Form
    const rideSearchForm = document.querySelector('.ride-search-form');
    if (rideSearchForm) {
        rideSearchForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleRideSearch();
        });
    }
    
    // Create Ride Form
    const createRideForm = document.querySelector('.create-ride-form');
    if (createRideForm) {
        createRideForm.addEventListener('submit', function(e) {
            e.preventDefault();
            handleCreateRide();
        });
    }
}

function handleLogin() {
    // Simulate login
    currentUser = {
        name: 'Alex Johnson',
        role: 'user',
        ecoContribution: '124 kg CO2 saved'
    };
    
    hideModal('loginModal');
    updateLoginState();
    showNotification('Login successful!', 'success');
}

function handleSignup() {
    // Get form data
    const nameInput = document.querySelector('.signup-form input[type="text"]');
    const emailInput = document.querySelector('.signup-form input[type="email"]');
    const roleSelect = document.querySelector('.signup-form select');
    
    const name = nameInput ? nameInput.value : 'New User';
    const role = roleSelect ? roleSelect.value : 'Passenger';
    
    currentUser = {
        name: name,
        role: role.toLowerCase(),
        ecoContribution: '0 kg CO2 saved'
    };
    
    hideModal('signupModal');
    updateLoginState();
    showNotification('Account created successfully!', 'success');
}

function handleRideSearch() {
    const fromLocation = document.getElementById('fromLocation');
    const toLocation = document.getElementById('toLocation');
    
    const fromValue = fromLocation ? fromLocation.value.trim() : '';
    const toValue = toLocation ? toLocation.value.trim() : '';
    
    console.log('Search values:', fromValue, toValue);
    
    if (!fromValue || !toValue) {
        showNotification('Please enter both pickup and drop locations', 'warning');
        return;
    }
    
    // Filter available rides (simulate search)
    searchResults = appData.routes.filter(route => {
        return route.from.toLowerCase().includes(fromValue.toLowerCase()) ||
               route.to.toLowerCase().includes(toValue.toLowerCase()) ||
               fromValue.toLowerCase().includes(route.from.toLowerCase()) ||
               toValue.toLowerCase().includes(route.to.toLowerCase());
    });
    
    if (searchResults.length === 0) {
        searchResults = appData.routes; // Show all rides if no match
        showNotification('No exact matches found. Showing all available rides.', 'info');
    } else {
        showNotification(`Found ${searchResults.length} matching rides`, 'success');
    }
    
    loadAvailableRides();
}

function handleCreateRide() {
    showNotification('Ride created successfully! Passengers can now book.', 'success');
    
    // Reset form
    const createRideForm = document.querySelector('.create-ride-form');
    if (createRideForm) {
        createRideForm.reset();
    }
}

// Role Card Handlers
function initializeRoleCards() {
    const roleCards = document.querySelectorAll('.role-card');
    console.log('Found role cards:', roleCards.length);
    
    roleCards.forEach((card, index) => {
        // Remove existing listeners by cloning
        const newCard = card.cloneNode(true);
        card.parentNode.replaceChild(newCard, card);
        
        newCard.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation();
            const role = this.getAttribute('data-role');
            console.log('Role card clicked:', role);
            if (role) {
                switchView(role);
            }
        });
    });
}

// Data Loading Functions
function loadInitialData() {
    setTimeout(() => {
        loadAvailableRides();
    }, 100);
}

function loadAvailableRides() {
    if (!ridesContainer) {
        ridesContainer = document.getElementById('ridesContainer');
    }
    
    if (!ridesContainer) {
        console.log('Rides container not found');
        return;
    }
    
    const rides = searchResults.length > 0 ? searchResults : appData.routes;
    console.log('Loading rides:', rides.length);
    
    ridesContainer.innerHTML = '';
    
    rides.forEach((route, index) => {
        const driver = appData.drivers[index % appData.drivers.length];
        const rideCard = createRideCard(route, driver);
        ridesContainer.appendChild(rideCard);
    });
}

function createRideCard(route, driver) {
    const card = document.createElement('div');
    card.className = 'ride-card';
    
    const safetyClass = getSafetyClass(route.safetyScore);
    const safetyText = getSafetyText(route.safetyScore);
    
    card.innerHTML = `
        <div class="ride-header">
            <div class="ride-route">
                <div class="route-text">${route.from} → ${route.to}</div>
                <div class="ride-details">
                    <span>${route.distance}</span>
                    <span>${route.duration}</span>
                    <span>${route.availableSeats} seats available</span>
                </div>
            </div>
            <div class="ride-price">${route.price}</div>
        </div>
        
        <div class="ride-meta">
            <div class="safety-score">
                <div class="safety-indicator ${safetyClass}"></div>
                <span>Safety: ${safetyText} (${route.safetyScore}%)</span>
            </div>
            <div class="eco-impact">🌱 ${route.ecoImpact}</div>
        </div>
        
        <div class="driver-info">
            <div class="driver-details">
                <h4>${driver.name}</h4>
                <div class="driver-meta">
                    ⭐ ${driver.rating} • ${driver.vehicle} • ${driver.rides} rides
                </div>
            </div>
            <div class="driver-actions">
                <button class="btn btn--primary btn--sm book-ride-btn" data-ride-id="${route.id}">
                    Book Ride
                </button>
            </div>
        </div>
    `;
    
    return card;
}

function getSafetyClass(score) {
    if (score >= 90) return 'safety-high';
    if (score >= 75) return 'safety-medium';
    return 'safety-low';
}

function getSafetyText(score) {
    if (score >= 90) return 'Excellent';
    if (score >= 75) return 'Good';
    return 'Fair';
}

// Admin Dashboard Functions
function initializeAdminChart() {
    const ctx = document.getElementById('ecoChart');
    if (!ctx) {
        console.log('Eco chart canvas not found');
        return;
    }
    
    // Clear any existing chart
    if (window.adminChart) {
        window.adminChart.destroy();
    }
    
    try {
        window.adminChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                datasets: [{
                    label: 'CO₂ Reduction (tons)',
                    data: [12.5, 15.2, 18.7, 16.3, 19.8, 22.1],
                    borderColor: '#1FB8CD',
                    backgroundColor: 'rgba(31, 184, 205, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    },
                    x: {
                        grid: {
                            color: 'rgba(0,0,0,0.1)'
                        }
                    }
                }
            }
        });
        console.log('Admin chart initialized successfully');
    } catch (error) {
        console.error('Error initializing admin chart:', error);
    }
}

function updateAdminDashboard() {
    // Simulate real-time updates
    updateSystemStats();
    updateSafetyAlerts();
}

function updateSystemStats() {
    // Update stats with small random variations
    const stats = appData.systemStats;
    
    // Simulate slight increases
    stats.totalUsers += Math.floor(Math.random() * 5);
    stats.ridesCompleted += Math.floor(Math.random() * 10);
    
    console.log('Updated system stats:', stats);
}

function updateSafetyAlerts() {
    // Simulate new safety alerts
    const alertsContainer = document.querySelector('.safety-alerts');
    if (alertsContainer && Math.random() > 0.8) {
        const newAlert = document.createElement('div');
        newAlert.className = 'alert alert--info';
        newAlert.innerHTML = `
            <strong>New Update:</strong> Safety patrol added to Route ${Math.floor(Math.random() * 10) + 1}
        `;
        alertsContainer.prepend(newAlert);
        
        // Remove old alerts if too many
        const alerts = alertsContainer.querySelectorAll('.alert');
        if (alerts.length > 3) {
            alerts[alerts.length - 1].remove();
        }
    }
}

// Utility Functions
function bookRide(rideId) {
    console.log('Booking ride:', rideId);
    
    if (!currentUser) {
        showModal('loginModal');
        return;
    }
    
    const ride = appData.routes.find(r => r.id === rideId);
    if (ride && ride.availableSeats > 0) {
        ride.availableSeats--;
        showNotification(`Ride booked successfully! ${ride.from} to ${ride.to}`, 'success');
        loadAvailableRides(); // Refresh the display
        
        // Simulate payment process
        setTimeout(() => {
            showNotification('Payment processed. Have a safe trip!', 'success');
        }, 2000);
    } else {
        showNotification('Sorry, no seats available for this ride.', 'error');
    }
}

function showNotification(message, type = 'info') {
    console.log('Notification:', message, type);
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification notification--${type}`;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        padding: 12px 20px;
        border-radius: 8px;
        color: white;
        font-weight: 500;
        z-index: 1001;
        max-width: 300px;
        word-wrap: break-word;
        transition: all 0.3s ease;
    `;
    
    // Set background color based on type
    const colors = {
        success: '#22c55e',
        error: '#ef4444',
        warning: '#f59e0b',
        info: '#3b82f6'
    };
    
    notification.style.backgroundColor = colors[type] || colors.info;
    notification.textContent = message;
    
    // Add to DOM
    document.body.appendChild(notification);
    
    // Auto remove after 3 seconds
    setTimeout(() => {
        notification.style.opacity = '0';
        notification.style.transform = 'translateX(100%)';
        setTimeout(() => {
            if (notification.parentNode) {
                notification.parentNode.removeChild(notification);
            }
        }, 300);
    }, 3000);
}

function updateLoginState() {
    if (currentUser) {
        if (loginBtn) {
            loginBtn.textContent = currentUser.name;
        }
        if (signupBtn) {
            signupBtn.style.display = 'none';
        }
        
        // Update profile displays
        document.querySelectorAll('.user-profile span').forEach(span => {
            span.textContent = `Welcome, ${currentUser.name}!`;
        });
        
        document.querySelectorAll('.eco-badge').forEach(badge => {
            badge.textContent = `🌱 ${currentUser.ecoContribution}`;
        });
    }
}

function setCurrentDate() {
    const dateInput = document.getElementById('rideDate');
    if (dateInput) {
        const today = new Date();
        dateInput.value = today.toISOString().split('T')[0];
    }
}

// Event Delegation for Dynamic Content
document.addEventListener('click', function(e) {
    const target = e.target;
    const text = target.textContent.trim();
    
    console.log('Click event:', text);
    
    // Handle book ride buttons
    if (target.classList.contains('book-ride-btn')) {
        e.preventDefault();
        const rideId = parseInt(target.getAttribute('data-ride-id'));
        if (rideId) {
            bookRide(rideId);
        }
        return;
    }
    
    // Handle ride request actions (Accept/Decline)
    if (text === 'Accept') {
        e.preventDefault();
        target.textContent = 'Accepted';
        target.classList.remove('btn--primary');
        target.classList.add('btn--success');
        target.disabled = true;
        
        const declineBtn = target.previousElementSibling;
        if (declineBtn && declineBtn.textContent.trim() === 'Decline') {
            declineBtn.style.display = 'none';
        }
        
        showNotification('Ride request accepted!', 'success');
        return;
    }
    
    if (text === 'Decline') {
        e.preventDefault();
        const requestElement = target.closest('.ride-request');
        if (requestElement) {
            requestElement.style.opacity = '0.5';
        }
        target.textContent = 'Declined';
        target.disabled = true;
        
        const acceptBtn = target.nextElementSibling;
        if (acceptBtn && acceptBtn.textContent.trim() === 'Accept') {
            acceptBtn.style.display = 'none';
        }
        
        showNotification('Ride request declined', 'info');
        return;
    }
    
    // Handle navigation and start navigation buttons
    if (text === 'Start Navigation') {
        e.preventDefault();
        showNotification('Navigation started. Safe driving!', 'success');
        target.textContent = 'Navigation Active';
        target.classList.remove('btn--primary');
        target.classList.add('btn--success');
        return;
    }
    
    if (text === 'View Details') {
        e.preventDefault();
        showNotification('Ride details opened', 'info');
        return;
    }
    
    // Handle admin management buttons
    if (text === 'Manage Users') {
        e.preventDefault();
        showNotification('User management panel opened', 'info');
        return;
    }
    
    if (text === 'View Safety Reports') {
        e.preventDefault();
        showNotification('Safety reports loaded', 'info');
        return;
    }
    
    if (text === 'Send Package') {
        e.preventDefault();
        if (!currentUser) {
            showModal('loginModal');
        } else {
            showNotification('Package service booking opened', 'info');
        }
        return;
    }
    
    // Handle role card button clicks
    if (text === 'Get Started') {
        e.preventDefault();
        switchView('user');
        return;
    }
    
    if (text === 'Start Driving') {
        e.preventDefault();
        switchView('driver');
        return;
    }
    
    if (text === 'Admin Access') {
        e.preventDefault();
        switchView('admin');
        return;
    }
});

// Real-time Updates Simulation
setInterval(() => {
    if (currentView === 'admin') {
        updateAdminDashboard();
    }
}, 30000); // Update every 30 seconds

// Simulate ride requests for drivers
setInterval(() => {
    if (currentView === 'driver') {
        if (Math.random() > 0.7) {
            showNotification('New ride request received!', 'info');
        }
    }
}, 45000); // Check every 45 seconds

// Simulate eco-impact updates
setInterval(() => {
    if (currentUser && Math.random() > 0.8) {
        // Simulate completing a ride and updating eco contribution
        const currentContribution = parseInt(currentUser.ecoContribution.match(/\d+/)[0]) || 0;
        const newContribution = currentContribution + Math.floor(Math.random() * 5) + 1;
        currentUser.ecoContribution = `${newContribution} kg CO2 saved`;
        
        // Update display
        document.querySelectorAll('.eco-badge').forEach(badge => {
            badge.textContent = `🌱 ${currentUser.ecoContribution}`;
        });
    }
}, 60000); // Check every minute

// Initialize search functionality with auto-suggestions
setTimeout(() => {
    const fromLocation = document.getElementById('fromLocation');
    const toLocation = document.getElementById('toLocation');
    
    if (fromLocation && toLocation) {
        const locations = [
            'Connaught Place, Delhi',
            'Karol Bagh, Delhi', 
            'Dwarka, Delhi',
            'Cyber City, Gurgaon',
            'Noida Sector 62',
            'Aerocity',
            'India Gate, Delhi',
            'Janakpuri, Delhi',
            'Rohini, Delhi',
            'Ghaziabad'
        ];
        
        [fromLocation, toLocation].forEach(input => {
            input.addEventListener('focus', function() {
                if (!this.value) {
                    const randomLocation = locations[Math.floor(Math.random() * locations.length)];
                    this.placeholder = `e.g., ${randomLocation}`;
                }
            });
        });
    }
}, 500);